--[[ Guild Potions  v0.2

    v0.2: Make Potions uses the newer tradeskill window (recipe search + Combine)
          instead of placing ingredients one at a time. Recipes you haven't made
          before fall back to the old placement method.


    Fills guild potion orders from https://zlem-eq.github.io/pages/guild-potions.html
      1. Pulls the orders assigned to your maker name
      2. Buys the ingredients (Shadow Haven now, Plane of Knowledge later)
      3. Combines the potions in your medicine bag
      4. Parcels each order from the Bazaar and marks it complete on the page

    Start: /lua run guildpotions        Stop: Stop button, or /lua stop guildpotions
    Needs: MQ2Nav (with meshes) and MQ2EasyFind for travel.
    Combine approach based on MrInfernal's Potion Maker.
]]

local mq      = require('mq')
local ImGui   = require('ImGui')
local FS      = require('gp_firestore')
local Recipes = require('gp_recipes')
local Vendors = require('gp_vendors')
local Plan    = require('gp_plan')
local A       = require('gp_actions')

------------------------------------------------------------------------
-- Settings (per character) and saved merchant inventories (shared)
------------------------------------------------------------------------
local server = (mq.TLO.EverQuest.Server() or 'server'):gsub('%s+', '_')
local me     = mq.TLO.Me.CleanName() or 'char'
local settingsPath = string.format('%s/guildpotions_%s_%s.lua', mq.configDir, server, me)
A.learnedPath = mq.configDir .. '/guildpotions_vendors.lua'
A.notSold = Vendors.notSold or {}
FS.tempDir = mq.configDir

local settings = {
    maker        = 'Bingling',
    buyLocation  = 'Shadowhaven', -- or 'PoK'
    pauseMercs   = true,
    parcelDelay  = 1000, -- ms between parcel steps
    combineDelay = 1000, -- ms between tradeskill-window steps
}

local function loadTable(path)
    local f = loadfile(path)
    if not f then return nil end
    local ok, t = pcall(f)
    if ok and type(t) == 'table' then return t end
end

do
    local saved = loadTable(settingsPath)
    if saved then for k, v in pairs(saved) do settings[k] = v end end
    A.learned = loadTable(A.learnedPath) or {}
end

local function saveSettings() mq.pickle(settingsPath, settings) end
A.parcelDelay = settings.parcelDelay
A.combineDelay = settings.combineDelay or 1000

------------------------------------------------------------------------
-- State
------------------------------------------------------------------------
local logLines = {}
local newLogLine = false
A.log = function(msg)
    print('\at[GuildPotions]\ax ' .. msg)
    local clean = msg:gsub('\a%-?.', '')
    logLines[#logLines + 1] = os.date('%I:%M:%S %p') .. '  ' .. clean
    if #logLines > 300 then table.remove(logLines, 1) end
    newLogLine = true
end

local makers      = {}
local orders      = {}
local selected    = {}   -- order id -> true/false
local plan        = nil
local sellerOf    = {}   -- ingredient -> merchant name (for display)
local job         = 'refresh'
local busy        = nil
local openGUI     = true
local lastPlan    = 0

local function selectedOrders()
    local out = {}
    for _, o in ipairs(orders) do
        if selected[o.id] ~= false and not o.completed then out[#out + 1] = o end
    end
    return out
end

local function zoneData() return Vendors[settings.buyLocation] or Vendors.Shadowhaven end

local function rebuildPlan()
    plan = Plan.build(selectedOrders(), Recipes, A.count)
    sellerOf = {}
    local visits, unknown = Plan.assignVendors(plan, zoneData(), A.learned, A.notSold)
    for _, v in ipairs(visits) do
        for _, it in ipairs(v.items) do sellerOf[it.name] = v.merchant.name end
    end
    for _, u in ipairs(unknown) do sellerOf[u.name] = '?' end
    for _, n in ipairs(A.notSold) do sellerOf[n] = 'drop' end
    lastPlan = os.time()
end

local function refresh()
    local m, err = FS.getMakers()
    if m then makers = m else A.log('\arCould not load makers: ' .. tostring(err)) end

    local o, err2 = FS.getAssignedOrders(settings.maker)
    if not o then
        A.log('\arCould not load orders: ' .. tostring(err2))
        return
    end
    orders = o
    A.log(string.format('Loaded %d open order(s) for %s.', #orders, settings.maker))
    rebuildPlan()
end

-- Everything still to make, after what's in bags right now
local function planDone()
    for _, key in ipairs(plan.potionOrder) do
        if plan.potions[key].toMake > 0 then return false end
    end
    return true
end

-- True when every unfinished potion needs an enemy drop (e.g. Deepwater Ink) that
-- we're out of, so buying more of the other ingredients can't help.
local function onlyDropsShort()
    local drop = {}
    for _, n in ipairs(A.notSold) do drop[n:lower()] = true end
    for _, key in ipairs(plan.potionOrder) do
        local e = plan.potions[key]
        if e.toMake > 0 then
            local blocked = false
            for mat, qty in pairs(e.recipe.mats) do
                if drop[mat:lower()] and A.count(mat) < qty then blocked = true end
            end
            if not blocked then return false end
        end
    end
    return true
end

-- Total ingredients in bags for the current plan. If this didn't drop during a
-- make round, no combine could even be attempted (a failed combine still uses them up).
local function ingredientsInBags()
    local n = 0
    for _, mat in ipairs(plan.matOrder) do n = n + A.count(mat) end
    return n
end

-- Make until every selected order is filled. Failed combines use up ingredients,
-- so whenever making runs dry it goes back to the merchants for exactly what's
-- missing and carries on. Stops if a round makes no progress.
local function makeUntilDone(buyFirst)
    local maxRounds = 25
    for round = 1, maxRounds do
        if A.stopRequested then return false end
        rebuildPlan()
        if planDone() then return true end
        if round > 1 and onlyDropsShort() then
            A.log('\ayFinished everything except potions that need an enemy drop you are out of.')
            return false
        end
        if buyFirst or round > 1 then
            if round > 1 then A.log('\ayRan out of ingredients before finishing. Buying more and continuing.') end
            if not A.buyAll(plan, zoneData()) then return false end
            rebuildPlan()
        end
        local before = ingredientsInBags()
        A.makeAll(plan)
        rebuildPlan()
        if planDone() then return true end
        if onlyDropsShort() then
            A.log('\ayFinished everything except potions that need an enemy drop you are out of.')
            return false
        end
        rebuildPlan()
        if ingredientsInBags() >= before then
            A.log('\arNo combines could be done this round; stopping so it does not loop. See messages above.')
            return false
        end
    end
    A.log(string.format('\arStill not finished after %d buy-and-make rounds; stopping.', maxRounds))
    return false
end

local function runJob(name)
    A.stopRequested = false
    busy = name
    if name == 'refresh' then
        refresh()
    else
        if #selectedOrders() == 0 then
            A.log('No orders selected.')
        else
            if settings.pauseMercs then A.pauseMercs(true) end
            rebuildPlan()
            local ok = true
            if name == 'buy' then ok = A.buyAll(plan, zoneData()) end
            if name == 'make' then ok = makeUntilDone(false) end
            if name == 'all' then ok = makeUntilDone(true) end
            -- Do All still parcels the orders that are complete, even if some can't be finished
            if name == 'parcel' or (name == 'all' and not A.stopRequested) then
                local parceled = A.parcelAll(selectedOrders(), Recipes)
                ok = ok and parceled
            end
            if name == 'all' and not ok then A.log('\ayDo All finished with some orders still open; see messages above.') end
            A.pauseMercs(false)
            rebuildPlan()
        end
    end
    busy = nil
end

------------------------------------------------------------------------
-- Window
------------------------------------------------------------------------
local red    = ImVec4(1.0, 0.45, 0.45, 1)
local yellow = ImVec4(1.0, 0.85, 0.35, 1)
local green  = ImVec4(0.45, 1.0, 0.5, 1)

local buyChoices = { 'Shadow Haven', 'Plane of Knowledge' }
local buyKeys    = { 'Shadowhaven', 'PoK' }

local function indexOf(list, v)
    for i, x in ipairs(list) do if x == v then return i end end
end

local function drawWindow()
    ImGui.SetNextWindowSize(640, 560, ImGuiCond.FirstUseEver)
    local show
    openGUI, show = ImGui.Begin('Guild Potions', openGUI)
    if not show then ImGui.End(); return end

    -- Maker name
    local makerList = {}
    for _, n in ipairs(makers) do makerList[#makerList + 1] = n end
    if not indexOf(makerList, settings.maker) then table.insert(makerList, 1, settings.maker) end
    ImGui.SetNextItemWidth(180)
    local mi = ImGui.Combo('Maker', indexOf(makerList, settings.maker) or 1, makerList, #makerList)
    if makerList[mi] and makerList[mi] ~= settings.maker then
        settings.maker = makerList[mi]; saveSettings(); job = 'refresh'
    end

    ImGui.SameLine()
    ImGui.SetNextItemWidth(170)
    local bi = ImGui.Combo('Buy at', indexOf(buyKeys, settings.buyLocation) or 1, buyChoices, #buyChoices)
    if buyKeys[bi] ~= settings.buyLocation then
        settings.buyLocation = buyKeys[bi]; saveSettings(); rebuildPlan()
    end

    local pm = ImGui.Checkbox('Pause RGMercs while working', settings.pauseMercs)
    if pm ~= settings.pauseMercs then settings.pauseMercs = pm; saveSettings() end

    ImGui.SameLine()
    ImGui.SetNextItemWidth(120)
    local pd = ImGui.SliderInt('Parcel step delay (ms)', settings.parcelDelay, 300, 3000)
    if pd and pd ~= settings.parcelDelay then
        settings.parcelDelay = pd; A.parcelDelay = pd; saveSettings()
    end

    ImGui.SetNextItemWidth(120)
    local cd = ImGui.SliderInt('Combine step delay (ms)', settings.combineDelay or 1000, 300, 3000)
    if cd and cd ~= settings.combineDelay then
        settings.combineDelay = cd; A.combineDelay = cd; saveSettings()
    end

    ImGui.Separator()
    if busy then
        ImGui.TextColored(yellow, 'Working: ' .. busy .. '   (do not click in game)')
        ImGui.SameLine()
        if ImGui.Button('Stop') then
            A.stopRequested = true
            mq.cmd('/nav stop')
            mq.cmd('/travelto stop')
        end
    else
        if ImGui.Button('Refresh Orders') then job = 'refresh' end
        ImGui.SameLine()
        if ImGui.Button('Buy Ingredients') then job = 'buy' end
        ImGui.SameLine()
        if ImGui.Button('Make Potions') then job = 'make' end
        ImGui.SameLine()
        if ImGui.Button('Parcel & Complete') then job = 'parcel' end
        ImGui.SameLine()
        if ImGui.Button('Do All') then job = 'all' end
    end

    -- Orders
    ImGui.Separator()
    ImGui.Text(string.format('Open orders for %s: %d', settings.maker, #orders))
    for _, o in ipairs(orders) do
        local stacks, lines = 0, {}
        for _, p in ipairs(o.potions or {}) do
            stacks = stacks + (p.stacks or 0)
            lines[#lines + 1] = string.format('%d x %s', p.stacks or 0, p.name)
        end
        local label = string.format('%s - %d stack%s##%s', o.playerName or '?', stacks, stacks == 1 and '' or 's', o.id)
        if o.completed then
            ImGui.TextColored(green, 'Done: ' .. (o.playerName or '?'))
        else
            local v = ImGui.Checkbox(label, selected[o.id] ~= false)
            if v ~= (selected[o.id] ~= false) then selected[o.id] = v; rebuildPlan() end
        end
        if ImGui.IsItemHovered() then ImGui.SetTooltip(table.concat(lines, '\n')) end
    end

    if plan then
        for name, stacks in pairs(plan.unknown) do
            ImGui.TextColored(red, string.format('No recipe for "%s" (%d stacks): make and parcel it yourself.', name, stacks))
        end

        if ImGui.CollapsingHeader('Potions to make', ImGuiTreeNodeFlags.DefaultOpen) then
            if ImGui.BeginTable('gp_potions', 4, ImGuiTableFlags.Borders) then
                ImGui.TableSetupColumn('Potion'); ImGui.TableSetupColumn('Need')
                ImGui.TableSetupColumn('Have'); ImGui.TableSetupColumn('Combines')
                ImGui.TableHeadersRow()
                for _, key in ipairs(plan.potionOrder) do
                    local e = plan.potions[key]
                    ImGui.TableNextRow()
                    ImGui.TableNextColumn(); ImGui.Text(e.recipe.item)
                    ImGui.TableNextColumn(); ImGui.Text(tostring(e.units))
                    ImGui.TableNextColumn()
                    if e.have >= e.units then ImGui.TextColored(green, tostring(e.have)) else ImGui.Text(tostring(e.have)) end
                    ImGui.TableNextColumn(); ImGui.Text(tostring(e.combines))
                end
                ImGui.EndTable()
            end
        end

        if ImGui.CollapsingHeader('Ingredients', ImGuiTreeNodeFlags.DefaultOpen) then
            if ImGui.BeginTable('gp_mats', 5, ImGuiTableFlags.Borders) then
                ImGui.TableSetupColumn('Ingredient'); ImGui.TableSetupColumn('Need')
                ImGui.TableSetupColumn('Have'); ImGui.TableSetupColumn('Buy')
                ImGui.TableSetupColumn('Merchant')
                ImGui.TableHeadersRow()
                for _, mat in ipairs(plan.matOrder) do
                    local m = plan.mats[mat]
                    ImGui.TableNextRow()
                    ImGui.TableNextColumn(); ImGui.Text(mat)
                    ImGui.TableNextColumn(); ImGui.Text(tostring(m.need))
                    ImGui.TableNextColumn(); ImGui.Text(tostring(m.have))
                    ImGui.TableNextColumn()
                    if m.short > 0 then ImGui.TextColored(yellow, tostring(m.short)) else ImGui.TextColored(green, '0') end
                    ImGui.TableNextColumn()
                    local s = sellerOf[mat]
                    if s == '?' then
                        ImGui.TextColored(red, 'no known seller')
                    elseif s == 'drop' then
                        if m.short > 0 then ImGui.TextColored(red, 'enemy drop - bring it') else ImGui.Text('enemy drop') end
                    else
                        ImGui.Text(s or '')
                    end
                end
                ImGui.EndTable()
            end
        end
    end

    if ImGui.CollapsingHeader('Messages', ImGuiTreeNodeFlags.DefaultOpen) then
        -- Own scrolling pane. Follows the newest line unless you've scrolled up to read.
        if ImGui.BeginChild('##gp_messages', ImVec2(0, 200), ImGuiChildFlags.Borders, ImGuiWindowFlags.HorizontalScrollbar) then
            local atBottom = ImGui.GetScrollY() >= ImGui.GetScrollMaxY() - 2
            for i = 1, #logLines do ImGui.TextWrapped(logLines[i]) end
            if newLogLine and atBottom then ImGui.SetScrollHereY(1.0) end
            newLogLine = false
        end
        ImGui.EndChild()
    end

    ImGui.End()
end

ImGui.Register('GuildPotions', drawWindow)

------------------------------------------------------------------------
-- Main loop
------------------------------------------------------------------------
A.log('Started. Maker: ' .. settings.maker .. ', buying at ' .. zoneData().label .. '.')
while openGUI do
    if job then
        local j = job
        job = nil
        local ok, err = pcall(runJob, j)
        if not ok then
            busy = nil
            A.pauseMercs(false)
            A.log('\arError: ' .. tostring(err))
        end
    elseif plan and os.time() - lastPlan >= 3 then
        rebuildPlan() -- keep "Have" counts current
    end
    mq.delay(200)
end
