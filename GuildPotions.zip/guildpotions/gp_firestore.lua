--[[ Guild Potions - talks to the guild page's Firebase (Firestore) database

    Uses Windows' built-in curl.exe through Lua's io.popen, so nothing extra needs
    installing. The project ID and API key are the same public values the guild
    page itself uses in the browser.

    These calls block for up to ~20s, so only call them from the main loop,
    never from inside the ImGui window function.
]]

local json = require('gp_json')

local FS = {
    projectId = 'everquest-guild-potions',
    apiKey    = 'AIzaSyCmB3wHICxm3jS6J25R55dR2Mrp06IqBBM',
    tempDir   = '.',
}

local function base()
    return string.format('https://firestore.googleapis.com/v1/projects/%s/databases/(default)/documents', FS.projectId)
end

-- Convert a Firestore typed value into a plain Lua value.
local fromFields
local function fromValue(v)
    if type(v) ~= 'table' then return nil end
    if v.stringValue ~= nil then return v.stringValue end
    if v.integerValue ~= nil then return tonumber(v.integerValue) end
    if v.doubleValue ~= nil then return tonumber(v.doubleValue) end
    if v.booleanValue ~= nil then return v.booleanValue end
    if v.timestampValue ~= nil then return v.timestampValue end
    if v.arrayValue ~= nil then
        local out = {}
        for _, x in ipairs(v.arrayValue.values or {}) do out[#out + 1] = fromValue(x) end
        return out
    end
    if v.mapValue ~= nil then return fromFields(v.mapValue.fields or {}) end
    return nil
end

fromFields = function(fields)
    local out = {}
    for k, v in pairs(fields or {}) do out[k] = fromValue(v) end
    return out
end

local function docToTable(doc)
    local t = fromFields(doc.fields)
    t.id = (doc.name or ''):match('([^/]+)$')
    return t
end

-- Run curl and return the decoded JSON, or nil + an error message.
local function curl(method, url, body)
    local cmd
    if body then
        local path = FS.tempDir .. '\\guildpotions_request.json'
        local f, ferr = io.open(path, 'w')
        if not f then return nil, 'could not write temp file: ' .. tostring(ferr) end
        f:write(json.encode(body))
        f:close()
        cmd = string.format('curl.exe -s -S --max-time 20 -X %s -H "Content-Type: application/json" --data-binary "@%s" "%s" 2>&1',
            method, path, url)
    else
        cmd = string.format('curl.exe -s -S --max-time 20 -X %s "%s" 2>&1', method, url)
    end

    local p = io.popen(cmd)
    if not p then return nil, 'could not start curl.exe' end
    local out = p:read('*a') or ''
    p:close()

    if out == '' then return nil, 'no response from the guild database' end
    local data, perr = json.decode(out)
    if data == nil then return nil, 'unexpected reply: ' .. out:sub(1, 200) .. (perr and (' (' .. perr .. ')') or '') end
    if type(data) == 'table' and data.error then
        local e = data.error
        if type(e) == 'table' then e = (e.status or '') .. ' ' .. (e.message or '') end
        return nil, 'database error: ' .. tostring(e)
    end
    if type(data) == 'table' and data[1] and type(data[1]) == 'table' and data[1].error then
        return nil, 'database error: ' .. tostring(data[1].error.message)
    end
    return data
end

--- List of maker names, as shown in the page's "Assign Maker" list.
function FS.getMakers()
    local data, err = curl('GET', base() .. '/makers?pageSize=300&key=' .. FS.apiKey)
    if not data then return nil, err end
    local names = {}
    for _, doc in ipairs(data.documents or {}) do
        local m = docToTable(doc)
        if m.name and m.name ~= '' then names[#names + 1] = m.name end
    end
    table.sort(names, function(a, b) return a:lower() < b:lower() end)
    return names
end

--- Orders assigned to this maker that are not complete yet.
--- Each order: { id, playerName, potions = { {name, category, stacks}, ... }, orderedAt, assignedTo, status }
function FS.getAssignedOrders(maker)
    local body = {
        structuredQuery = {
            from = { { collectionId = 'orders' } },
            where = {
                compositeFilter = {
                    op = 'AND',
                    filters = {
                        { fieldFilter = { field = { fieldPath = 'assignedTo' }, op = 'EQUAL', value = { stringValue = maker } } },
                        { fieldFilter = { field = { fieldPath = 'status' }, op = 'EQUAL', value = { stringValue = 'assigned' } } },
                    },
                },
            },
        },
    }
    local data, err = curl('POST', base() .. ':runQuery?key=' .. FS.apiKey, body)
    if not data then return nil, err end
    local orders = {}
    for _, row in ipairs(data) do
        if row.document then orders[#orders + 1] = docToTable(row.document) end
    end
    table.sort(orders, function(a, b) return tostring(a.orderedAt or '') < tostring(b.orderedAt or '') end)
    return orders
end

--- Same change as the page's "Mark Complete" button.
function FS.markComplete(orderId)
    local url = string.format('%s/orders/%s?updateMask.fieldPaths=status&currentDocument.exists=true&key=%s',
        base(), orderId, FS.apiKey)
    local data, err = curl('PATCH', url, { fields = { status = { stringValue = 'complete' } } })
    if not data then return false, err end
    local doc = docToTable(data)
    if doc.status ~= 'complete' then return false, 'database did not confirm the change' end
    return true
end

return FS
