--[[ Guild Potions - recipes

    Copied from the POTION_RECIPES table on https://zlem-eq.github.io/pages/guild-potions.html
    so in-game math matches the page's calculator. Keys are the potion names used on
    the order board. yield = potions per combine; mats = quantity per combine.
    If you add a potion to the page, add the same line here.
]]

local R = {
    ['Heat Awareness 3']      = { item = 'Heat Awareness III',    id = 55891, yield = 1, mats = { ['Briar Thistle'] = 1, ['Figwort'] = 1, ['Lucerne'] = 1 } },
    ['Cold Awareness 3']      = { item = 'Cold Awareness III',    id = 55827, yield = 1, mats = { ['Benzoin'] = 1, ['Briar Thistle'] = 1, ['Figwort'] = 1 } },
    ['Poison Awareness 3']    = { item = 'Poison Awareness III',  id = 55927, yield = 1, mats = { ['Briar Thistle'] = 1, ['Figwort'] = 1, ['Night Shade'] = 1 } },
    ['Benefit Awareness 3']   = { item = 'Benefit Awareness III', id = 55807, yield = 1, mats = { ['Briar Thistle'] = 1, ['Figwort'] = 1, ['Sage Leaf'] = 1 } },
    ['Magic Awareness 3']     = { item = 'Magic Awareness III',   id = 55911, yield = 1, mats = { ['Briar Thistle'] = 1, ['Figwort'] = 1, ['Mandrake Root'] = 1 } },
    ['Disease Awareness 3']   = { item = 'Disease Awareness III', id = 55843, yield = 1, mats = { ['Birthwort'] = 1, ['Briar Thistle'] = 1, ['Figwort'] = 1 } },

    ['Minor Potion of Cold (Fire)']           = { item = 'Minor Potion of Cold',       id = 54353, yield = 1, mats = { ['Allspice'] = 1, ['Birthwort'] = 1 } },
    ['Minor Potion of Heat (Cold)']           = { item = 'Minor Potion of Heat',       id = 54365, yield = 1, mats = { ['Benzoin'] = 1, ['Sage Leaf'] = 1 } },
    ['Minor Null Potion (Magic)']             = { item = 'Minor Null Potion',          id = 54517, yield = 1, mats = { ['Fenugreek'] = 1, ['Mandrake Root'] = 1 } },
    ['Minor Potion of Antibody (Disease)']    = { item = 'Minor Potion of Antibody',   id = 54317, yield = 1, mats = { ['Maidenhair Fern'] = 1, ['Mullein'] = 1 } },
    ['Minor Potion of Purity (Poison)']       = { item = 'Minor Potion of Purity',     id = 54393, yield = 1, mats = { ['Lucerne'] = 1, ['Night Shade'] = 1 } },
    ["Kithar's Disease Treatment (Cure)"]     = { item = "Kithar's Disease Treatment", id = 54441, yield = 1, mats = { ['Echinacea'] = 1, ["Lady's Mantle"] = 1 } },
    ["Ethira's Poison Antidote (Cure)"]       = { item = "Ethira's Poison Antidote",   id = 54437, yield = 1, mats = { ['Hyssop'] = 1, ["Lady's Mantle"] = 1 } },
    ['Elixir of Divine Endurance (10allres)'] = { item = 'Elixir of Divine Endurance', id = 54497, yield = 1, mats = { ['Betherium Bark'] = 1, ['Blade Leaf'] = 1 } },

    ['Potion of Power (STR/DEX)']       = { item = 'Potion of Power',      id = 54385, yield = 1, mats = { ['Blue Vervain Bulb'] = 1, ['Fenugreek'] = 1, ['Lucerne'] = 1 } },
    ['Potion of Vigor (STR/AGI)']       = { item = 'Potion of Vigor',      id = 54409, yield = 1, mats = { ['Birthwort'] = 1, ['Blue Vervain Bulb'] = 1, ['Lucerne'] = 1 } },
    ['Potion of Stability (STR/STAM)']  = { item = 'Potion of Stability',  id = 54537, yield = 1, mats = { ['Blue Vervain Bulb'] = 1, ['Lucerne'] = 1, ['Sage Leaf'] = 1 } },
    ['Potion of Cohesion (DEX/STAM)']   = { item = 'Potion of Cohesion',   id = 54337, yield = 1, mats = { ['Blue Vervain Bulb'] = 1, ['Fenugreek'] = 1, ['Sage Leaf'] = 1 } },
    ['Potion of Accuracy (DEX/AGI)']    = { item = 'Potion of Accuracy',   id = 54345, yield = 1, mats = { ['Birthwort'] = 1, ['Blue Vervain Bulb'] = 1, ['Fenugreek'] = 1 } },
    ['Potion of Adroitness (STAM/AGI)'] = { item = 'Potion of Adroitness', id = 54341, yield = 1, mats = { ['Birthwort'] = 1, ['Blue Vervain Bulb'] = 1, ['Sage Leaf'] = 1 } },

    ['Gate Potion']                         = { item = 'Gate Potion',              id = 54277, yield = 1, mats = { ['Heliotrope'] = 3 } },
    -- These two are orderable on the page but missing from its calculator; recipes from EQ Traders Corner
    -- (reverse recipe search for Heliotrope). Item IDs not looked up; the script only uses item names.
    ['Frost Potion (Everfrost)']            = { item = 'Potion of the Frost',      yield = 1, mats = { ['Heliotrope'] = 1, ['Oakmoss'] = 1 } },
    ['Field of Bone Potion']                = { item = 'Potion of the Bone Field', yield = 1, mats = { ['Heliotrope'] = 1, ['Sandalwood'] = 1 } },
    ['Potion of the Swamp - Innothule Sw.'] ={ item = 'Potion of the Swamp',      id = 54477, yield = 1, mats = { ['Bladderwrack'] = 1, ['Heliotrope'] = 1 } },
    ['Potion of Twilight Mists (Luclin)']   = { item = 'Potion of Twilight Mists', id = 56616, yield = 1, mats = { ['Heliotrope'] = 1, ['Star Reach Clover'] = 1 } },

    ['Celestial Healing Distillate']        = { item = 'Distillate of Celestial Healing IX', id = 20721, yield = 5, mats = { ['Comfrey'] = 1, ['Deepwater Ink'] = 1, ['Gerti Blossom'] = 1, ['Small Vial'] = 5 } },
    ['Divine Healing Distillate']           = { item = 'Distillate of Divine Healing IX',    id = 20731, yield = 5, mats = { ['Comfrey'] = 1, ['Deepwater Ink'] = 1, ['Tregrum'] = 1, ['Small Vial'] = 5 } },
    ['Distillate of Clarity']               = { item = 'Distillate of Clarity IX',           id = 20701, yield = 5, mats = { ['Comfrey'] = 1, ['Deepwater Ink'] = 1, ['Katuka Bark'] = 1, ['Small Vial'] = 5 } },
    ['Distillate of Alacrity - Haste']      = { item = 'Distillate of Alacrity IX',          id = 20691, yield = 5, mats = { ['Arnworth'] = 1, ['Comfrey'] = 1, ['Deepwater Ink'] = 1, ['Small Vial'] = 5 } },
    ['Distillate of Spirituality (Luclin)'] = { item = 'Distillate of Spirituality IX',      id = 30048, yield = 5, mats = { ['Comfrey'] = 1, ['Deepwater Ink'] = 1, ['Methysticum'] = 1, ['Small Vial'] = 5 } },

    ['Greater Concentration Potion']     = { item = 'Elixir of Greater Concentration', id = 54493, yield = 1, mats = { ['Duskglow Vine'] = 1, ['Violet Tri-Tube Sap'] = 1 } },
    ['Blood of the Wolf (SoW)']          = { item = 'Blood of the Wolf',               id = 54257, yield = 1, mats = { ['Birthwort'] = 1, ['Fenugreek'] = 1, ['Wolf Blood'] = 1 } },
    ['Potion of Unlife Awareness (IVU)'] = { item = 'Potion of Unlife Awareness',      id = 54261, yield = 1, mats = { ['Elderberry'] = 1, ['Fennel'] = 1 } },
    ["Kilva's Skin of Flame (DS)"]       = { item = "Kilva's Skin of Flame",           id = 54433, yield = 1, mats = { ['Clover'] = 1, ['Clubmoss'] = 1, ['Jatamasi'] = 1 } },
    ["Ant's Potion (Shrink)"]            = { item = "Ant's Potion",                    id = 54453, yield = 1, mats = { ['Celandine Herb'] = 1, ['Sumbul'] = 1 } },
    ['Army Ant Potion (GroupShrink)']    = { item = 'Army Ant Potion',                 id = 56139, yield = 1, mats = { ['Celandine Herb'] = 1, ['Feverfew'] = 1, ['Sumbul'] = 1, ['Valerian Root'] = 1 } },
    ['Potion of Antiweight (Levitate)']  = { item = 'Potion of Antiweight',            id = 54425, yield = 1, mats = { ['Hydrangea'] = 1, ['Sumbul'] = 1 } },
    ['Potion of Greater Rejuvenation']   = { item = 'Potion of Greater Rejuvenation',  id = 54417, yield = 1, mats = { ['Agrimony'] = 1, ['Lucerne'] = 1, ['Sage Leaf'] = 1 } },
}

-- Same rule as the page: distillates stack to 20, potions and elixirs to 10.
local function stackSize(recipe)
    if recipe.item:sub(1, 10) == 'Distillate' then return 20 end
    return 10
end

return { recipes = R, stackSize = stackSize }
