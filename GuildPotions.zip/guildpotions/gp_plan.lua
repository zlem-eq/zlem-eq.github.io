--[[ Guild Potions - works out what to make and what to buy

    Pure math, no game calls: inventory counts come in through the haveCount
    function, so this file can be tested outside the game.
]]

local Plan = {}

--- orders:    list of orders (only the ones ticked in the window)
--- data:      require('gp_recipes')
--- haveCount: function(itemName) -> number currently in bags
function Plan.build(orders, data, haveCount)
    local recipes, stackSize = data.recipes, data.stackSize
    local plan = { potions = {}, potionOrder = {}, mats = {}, matOrder = {}, unknown = {} }

    -- 1. Total potions ordered, per potion
    for _, order in ipairs(orders) do
        for _, p in ipairs(order.potions or {}) do
            local r = recipes[p.name]
            if not r then
                plan.unknown[p.name] = (plan.unknown[p.name] or 0) + (p.stacks or 0)
            else
                local e = plan.potions[p.name]
                if not e then
                    e = { key = p.name, recipe = r, stackSize = stackSize(r), stacks = 0 }
                    plan.potions[p.name] = e
                    plan.potionOrder[#plan.potionOrder + 1] = p.name
                end
                e.stacks = e.stacks + (p.stacks or 0)
            end
        end
    end
    table.sort(plan.potionOrder)

    -- 2. How many to make, after what's already in bags
    for _, key in ipairs(plan.potionOrder) do
        local e = plan.potions[key]
        e.units   = e.stacks * e.stackSize
        e.have    = haveCount(e.recipe.item) or 0
        e.toMake  = math.max(0, e.units - e.have)
        e.combines = math.ceil(e.toMake / e.recipe.yield)
        for mat, qty in pairs(e.recipe.mats) do
            local m = plan.mats[mat]
            if not m then
                m = { name = mat, need = 0 }
                plan.mats[mat] = m
                plan.matOrder[#plan.matOrder + 1] = mat
            end
            m.need = m.need + qty * e.combines
        end
    end
    table.sort(plan.matOrder)

    -- 3. What to buy
    for _, mat in ipairs(plan.matOrder) do
        local m = plan.mats[mat]
        m.have  = haveCount(mat) or 0
        m.short = math.max(0, m.need - m.have)
    end

    return plan
end

--- Units of each finished potion this one order needs: { [itemName] = units }
function Plan.orderUnits(order, data)
    local units, missing = {}, {}
    for _, p in ipairs(order.potions or {}) do
        local r = data.recipes[p.name]
        if r then
            units[r.item] = (units[r.item] or 0) + (p.stacks or 0) * data.stackSize(r)
        else
            missing[#missing + 1] = p.name
        end
    end
    return units, missing
end

--- Pick which merchant to use for each ingredient that is short.
--- zoneData: one entry of gp_vendors (e.g. vendors.Shadowhaven)
--- learned:  { ["zone|Merchant Name"] = { items... } } saved from earlier visits
--- notSold:   list of ingredient names nobody sells (must already be in bags)
--- Returns visits = { {merchant=..., items={ {name, qty}, ... }}, ... },
---         unknown = { {name, qty} } (no known seller) and bring = { {name, qty} } (drops you're short on)
function Plan.assignVendors(plan, zoneData, learned, notSold)
    local skip = {}
    for _, n in ipairs(notSold or {}) do skip[n:lower()] = true end
    local function sells(m)
        local list = learned[zoneData.zone .. '|' .. m.name] or m.sells or {}
        local set = {}
        for _, n in ipairs(list) do set[n:lower()] = true end
        return set
    end

    local merchants = {}
    for i, m in ipairs(zoneData.merchants) do
        merchants[i] = { merchant = m, set = sells(m), items = {}, known = (#(learned[zoneData.zone .. '|' .. m.name] or m.sells or {}) > 0) }
    end

    local unknown, bring = {}, {}
    for _, mat in ipairs(plan.matOrder) do
        local m = plan.mats[mat]
        if m.short > 0 and skip[mat:lower()] then
            bring[#bring + 1] = { name = mat, qty = m.short }
        elseif m.short > 0 then
            local placed = false
            for _, v in ipairs(merchants) do
                if v.set[mat:lower()] then
                    v.items[#v.items + 1] = { name = mat, qty = m.short }
                    placed = true
                    break
                end
            end
            if not placed then unknown[#unknown + 1] = { name = mat, qty = m.short } end
        end
    end

    -- Merchants whose stock we don't know yet get visited too when something
    -- has no known seller: they might carry it, and the visit records their stock.
    local visits = {}
    for _, v in ipairs(merchants) do
        if #v.items > 0 then
            visits[#visits + 1] = { merchant = v.merchant, items = v.items }
        elseif #unknown > 0 and not v.known then
            visits[#visits + 1] = { merchant = v.merchant, items = {}, explore = true }
        end
    end
    return visits, unknown, bring
end

return Plan
