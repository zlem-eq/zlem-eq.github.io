--[[ Guild Potions - merchant reference data

    Each "buy location" is a zone plus the merchants there and what they sell.
    The script uses this to decide which merchant to visit for each ingredient.

    Inventories come from EQ Traders Corner / Allakhazam. When the script opens
    a merchant in game it also saves that merchant's real inventory to
    config\guildpotions_vendors.lua, and that saved list wins over the one here.
    So an empty or out-of-date "sells" list fixes itself after one visit.

    To add a merchant: copy a block, set name (exactly as shown in game),
    loc (the /loc "y, x, z" for reference) and sells.
]]

return {
    order = { 'Shadowhaven', 'PoK', },

    -- Ingredients no merchant sells (enemy drops). The script never tries to buy
    -- these; they must already be in your bags, and it tells you if you're short.
    notSold = { 'Deepwater Ink', },

    Shadowhaven = {
        label = 'Shadow Haven',
        zone  = 'shadowhaven',
        merchants = {
            {
                name   = 'Donaidh MacFuller',
                loc    = '121, 1255, -55',
                source = 'https://www.eqtraders.com/sources/mob_item_list.php?MobID=3093',
                sells  = {
                    'Acaana', 'Agrimony', 'Allspice', 'Aloe', 'Angurth', 'Arroweed', 'Benzoin', 'Birthwort',
                    'Bitterwood', 'Bladderwrack', 'Boneset', 'Briar Thistle', 'Bulb Lotus', 'Burdock Root',
                    'Celandine Herb', 'Cententialspore', 'Clover', 'Clubmoss', 'Comfrey', 'Curuloth', 'Damiana',
                    'Dhea', 'Duskglow Vine', 'Echinacea', 'Elderberry', 'Eucalyptus Leaf', 'Eyebright', 'Fennel',
                    'Fenugreek', 'Feverfew', 'Figwort', 'Fire Spore', 'Flamewort', 'Gerti Blossom',
                    'Ground Figwort', 'Heliotrope', 'Hemlock Powder', 'Horehound', 'Hydrangea', 'Hyssop',
                    'Icicle Ivy', 'Jatamasi', 'Katuka Bark', "Lady's Mantle", 'Lucerne', 'Maidenhair Fern',
                    'Maliak Leaf', 'Mandrake Root', 'Measure of Wolf Blood', 'Mercury', 'Mullein', 'Mystic Ash',
                    'Night Shade', 'Oakmoss', 'Pickleberry Extract', 'Prism Grains', 'Sage Leaf', 'Sandalwood',
                    'Seathorn', 'Sickle Leaf', 'Star Reach Clover', 'Stinging Crystal', 'Sumbul', 'Suranie',
                    'Tregrum', 'Tri-Fern Leaf', 'Wolf Blood', 'Woundwart', 'Yellow Rheum', 'Yerbhimba',
                },
            },
            {
                name   = 'Zimloro Jalobottle',
                loc    = '-420, 1425, -52',
                source = 'https://everquest.allakhazam.com/db/npc.html?id=9864',
                sells  = {
                    'Arnworth', 'Bark Potion', 'Cententialspore', 'Chipped Bone Rod', 'Clivers', 'Cloudy Potion',
                    'Crimson Potion', 'Crystallized Pumice', 'Dufrenite', 'Fish Gill Extract', 'Gerti Blossom',
                    'Harvest Crystal', 'Katuka Bark', 'Methysticum', 'Mistletoe', 'Murky Vial', 'Pale Green Potion',
                    'Potion of Light Healing', 'Sandalwood', 'Small Vial', 'Spring Crystal', 'Tregrum',
                    'Vial of Swirling Smoke', 'Wrist Pouch',
                },
            },
            {
                name   = 'Steaon Alarenier',
                loc    = '267, 1572, -55',
                source = 'https://everquest.allakhazam.com/db/npc.html?id=7543',
                sells  = {
                    'Betherium Bark', 'Blade Leaf', 'Duskglow Vine', 'Maliak Leaf', 'Medicine Bag', 'Sickle Leaf',
                    'Star Reach Clover', 'Tri-Fern Leaf', 'Violet Tri-Tube Sap', 'Yerbhimba',
                },
            },
            {
                name   = 'Lemsen Frostherb',
                loc    = '121, 1207, -55',
                source = 'https://www.eqtraders.com/sources/mob_item_list.php?MobID=1837',
                sells  = {
                    'Agrimony', 'Allspice', 'Benzoin', 'Birthwort', 'Blue Nightwort', 'Blue Vervain Bulb',
                    'Celandine Herb', 'Fenugreek', 'Figwort', 'Fine Potion Vial', 'Gemmed Potion Vial', 'Lucerne',
                    'Maidenhair Fern', 'Mandrake Root', 'Marsh Algae', 'Measure of Wolf Blood', 'Medicine Bag',
                    'Mullein', 'Nettle Creeper', 'Night Shade', 'Notes of Jonas', 'Plain Potion Vial', 'Sage Leaf',
                    'Smooth Potion Vial', 'Storm Cloud', 'Valerian Root', 'Wolf Blood', 'Yarrow',
                },
            },
            {
                name   = 'Callowolf MacFuller',
                loc    = '121, 1228, -55',
                source = 'https://www.eqtraders.com/sources/mob_item_list.php?MobID=1838',
                sells  = {
                    'Agrimony', 'Allspice', 'Benzoin', 'Birthwort', 'Blue Nightwort', 'Blue Vervain Bulb',
                    'Celandine Herb', 'Fenugreek', 'Figwort', 'Fine Potion Vial', 'Gemmed Potion Vial', 'Lucerne',
                    'Maidenhair Fern', 'Mandrake Root', 'Marsh Algae', 'Measure of Wolf Blood', 'Medicine Bag',
                    'Mullein', 'Nettle Creeper', 'Night Shade', 'Notes of Jonas', 'Plain Potion Vial', "Ro's Breath",
                    'Sage Leaf', 'Smooth Potion Vial', 'Storm Cloud', 'Valerian Root', 'Wolf Blood', 'Yarrow',
                },
            },
        },
    },

    PoK = {
        label = 'Plane of Knowledge',
        zone  = 'poknowledge',
        merchants = {
            { name = 'Alchemist Redsa', loc = '-330, 814',        source = 'https://www.eqtraders.com/sources/mob_item_list.php?MobID=6903', sells = {}, },
            { name = 'Severg O`Danos',  loc = '-19, 1375, -107',  source = 'https://www.eqtraders.com/sources/mob_item_list.php?MobID=2504', sells = {}, },
            { name = 'Edvard O`Danos',  loc = '-38, 1356, -107',  source = 'https://www.eqtraders.com/sources/mob_item_list.php?MobID=5044', sells = {}, },
        },
    },
}
