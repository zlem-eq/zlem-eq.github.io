--[[ Guild Potions - in-game actions: travel, buy, combine, parcel

    Everything here runs from the main loop (never from the ImGui window) and
    checks A.stopRequested so the Stop button can interrupt it.
    Combine steps follow the approach used by MrInfernal's Potion Maker.
]]

local mq   = require('mq')
local Plan = require('gp_plan')
local FS   = require('gp_firestore')

local A = {
    stopRequested = false,
    log = function(msg) print(msg) end,
    learned = {},          -- merchant inventories seen in game
    learnedPath = nil,     -- where they're saved
    notSold = {},          -- enemy-drop ingredients, never bought
}

local function say(fmt, ...) A.log(string.format(fmt, ...)) end

-- Wait up to ms for cond() to be true; returns false if stopped or timed out.
local function waitFor(ms, cond)
    local t = 0
    while t < ms do
        if A.stopRequested then return false end
        if cond() then return true end
        mq.delay(100)
        t = t + 100
    end
    return cond()
end

-- Exact-name count in bags (plain FindItemCount would count "Star Reach Clover" as "Clover").
function A.count(name)
    return mq.TLO.FindItemCount('=' .. name)() or 0
end

------------------------------------------------------------------------
-- RGMercs pause while working
------------------------------------------------------------------------
local pausedMercs = false
function A.pauseMercs(on)
    local running = mq.TLO.Lua.Script('rgmercs').Status() == 'RUNNING'
    if on and running and not pausedMercs then
        mq.cmd('/rgl pause'); pausedMercs = true
    elseif not on and pausedMercs then
        if running then mq.cmd('/rgl unpause') end
        pausedMercs = false
    end
end

------------------------------------------------------------------------
-- Moving around
------------------------------------------------------------------------
function A.travelTo(zone)
    if (mq.TLO.Zone.ShortName() or ''):lower() == zone then return true end
    if not mq.TLO.Plugin('mq2easyfind').IsLoaded() then
        say('\arMQ2EasyFind is not loaded. Go to %s yourself, then press the button again.', zone)
        return false
    end
    say('Traveling to %s...', zone)
    mq.cmdf('/travelto %s', zone)
    local ok = waitFor(20 * 60 * 1000, function()
        return (mq.TLO.Zone.ShortName() or ''):lower() == zone and not mq.TLO.Me.Zoning()
    end)
    if not ok then
        mq.cmd('/travelto stop')
        say('\arDid not reach %s.', zone)
        return false
    end
    mq.delay(3000) -- let the zone finish loading spawns
    return true
end

local function nearest(filter)
    local best, bestDist
    for _, s in ipairs(mq.getFilteredSpawns(filter)) do
        local d = s.Distance() or 99999
        if not best or d < bestDist then best, bestDist = s, d end
    end
    return best
end

function A.findNpc(name)
    return nearest(function(s) return s.Type() == 'NPC' and s.CleanName() == name end)
end

function A.findParcelNpc()
    return nearest(function(s)
        if s.Type() ~= 'NPC' then return false end
        local tag = ((s.Surname() or '') .. ' ' .. (s.Title() or '')):lower()
        return tag:find('parcels', 1, true) ~= nil
    end)
end

function A.navTo(spawn)
    local id = spawn.ID()
    local function dist() return mq.TLO.Spawn('id ' .. id).Distance() or 99999 end
    if dist() < 15 then return true end
    if not mq.TLO.Plugin('mq2nav').IsLoaded() or not mq.TLO.Navigation.MeshLoaded() then
        say('\arMQ2Nav or its mesh is not loaded for this zone; walk to %s yourself.', spawn.CleanName())
        return false
    end
    mq.cmdf('/nav id %d', id)
    local ok = waitFor(180000, function() return dist() < 15 or not mq.TLO.Navigation.Active() end)
    if mq.TLO.Navigation.Active() then mq.cmd('/nav stop') end
    if not ok or dist() > 20 then
        say('\arCould not get close to %s.', spawn.CleanName())
        return false
    end
    return true
end

------------------------------------------------------------------------
-- Merchants
------------------------------------------------------------------------
function A.closeMerchant()
    if mq.TLO.Window('MerchantWnd').Open() then
        mq.TLO.Window('MerchantWnd').DoClose()
        waitFor(2000, function() return not mq.TLO.Window('MerchantWnd').Open() end)
    end
end

-- Close every open bag, the inventory window and the tradeskill window.
function A.closeBagsAndInventory()
    for slot = 23, 34 do
        local it = mq.TLO.Me.Inventory(slot)
        if it() and (it.Container() or 0) > 0 then
            local o = it.Open()
            if o == true or o == 1 then
                mq.cmdf('/nomodkey /itemnotify pack%d rightmouseup', slot - 22)
                mq.delay(200)
            end
        end
    end
    for _, wnd in ipairs({ 'TradeskillWnd', 'InventoryWindow' }) do
        if mq.TLO.Window(wnd).Open() then
            mq.TLO.Window(wnd).DoClose()
            mq.delay(200)
        end
    end
end

function A.openMerchant(spawn)
    A.closeMerchant()
    mq.cmdf('/target id %d', spawn.ID())
    waitFor(2000, function() return mq.TLO.Target.ID() == spawn.ID() end)
    mq.cmd('/click right target')
    if not waitFor(5000, function() return mq.TLO.Window('MerchantWnd').Open() end) then
        say('\arMerchant window did not open for %s.', spawn.CleanName())
        return false
    end
    waitFor(5000, function() return mq.TLO.Merchant.ItemsReceived() end)
    return true
end

function A.recordInventory(zone, merchantName)
    local items = {}
    for i = 1, (mq.TLO.Merchant.Items() or 0) do
        local n = mq.TLO.Merchant.Item(i).Name()
        if n then items[#items + 1] = n end
    end
    if #items > 0 then
        A.learned[zone .. '|' .. merchantName] = items
        if A.learnedPath then mq.pickle(A.learnedPath, A.learned) end
    end
    return items
end

local function buyOne(name, qty)
    local start = A.count(name)
    local target = start + qty
    mq.TLO.Merchant.SelectItem('=' .. name)
    if not waitFor(2000, function() return (mq.TLO.Merchant.SelectedItem.Name() or '') == name end) then
        return 0, 'not sold here'
    end
    local stalls = 0
    while A.count(name) < target and stalls < 2 do
        if A.stopRequested then break end
        local before = A.count(name)
        mq.TLO.Merchant.Buy(math.min(target - before, 100))
        if waitFor(4000, function() return A.count(name) > before end) then
            stalls = 0
            mq.delay(300)
        else
            stalls = stalls + 1
        end
    end
    local got = A.count(name) - start
    if got < qty then return got, 'stopped buying (out of money or bag space?)' end
    return got
end

--- Buy everything the plan is short on, in the chosen buy location.
function A.buyAll(plan, zoneData)
    local visits, unknown, bring = Plan.assignVendors(plan, zoneData, A.learned, A.notSold)
    for _, b in ipairs(bring) do
        say('\ay%s is not sold by merchants (enemy drop). You need %d more in your bags; orders using it will come up short.', b.name, b.qty)
    end
    if #visits == 0 and #unknown == 0 then
        say('\agNothing to buy, you have every ingredient.')
        return true
    end
    if not A.travelTo(zoneData.zone) then return false end

    for _, v in ipairs(visits) do
        if A.stopRequested then break end
        local m = v.merchant
        local spawn = A.findNpc(m.name)
        if not spawn then
            say('\ar%s is not up in %s right now; skipping.', m.name, zoneData.label)
        elseif A.navTo(spawn) and A.openMerchant(spawn) then
            local stock = A.recordInventory(zoneData.zone, m.name)
            local items = v.items
            if v.explore then
                -- check the merchant we knew nothing about for the unknown items
                local set = {}
                for _, n in ipairs(stock) do set[n:lower()] = true end
                items = {}
                for _, u in ipairs(unknown) do
                    if set[u.name:lower()] then items[#items + 1] = u end
                end
                say('Recorded %d items sold by %s.', #stock, m.name)
            end
            for _, it in ipairs(items) do
                if A.stopRequested then break end
                local need = it.qty
                local got, err = buyOne(it.name, need)
                if err then
                    say('\ay%s: bought %d of %d %s (%s).', m.name, got, need, it.name, err)
                else
                    say('\agBought %d %s from %s.', got, it.name, m.name)
                end
                it.qty = need - got
            end
            A.closeMerchant()
        end
    end

    A.closeBagsAndInventory() -- merchants open your bags and inventory; tidy up
    local dropSet = {}
    for _, n in ipairs(A.notSold or {}) do dropSet[n:lower()] = true end
    local stillShort = {}
    for _, mat in ipairs(plan.matOrder) do
        local m = plan.mats[mat]
        local short = m.need - A.count(mat)
        if short > 0 and not dropSet[mat:lower()] then stillShort[#stillShort + 1] = string.format('%d %s', short, mat) end
    end
    if #stillShort > 0 then
        say('\ayStill missing: %s', table.concat(stillShort, ', '))
        return false
    end
    -- Short only on enemy drops: carry on and make what can be made.
    say('\agAll purchasable ingredients bought.')
    return true
end

------------------------------------------------------------------------
-- Combining in the medicine bag
------------------------------------------------------------------------
local function packName(slot) return 'pack' .. (slot - 22) end

local function findMedBag()
    for slot = 23, 34 do
        local it = mq.TLO.Me.Inventory(slot)
        if it() and it.Type() == 'Medicine' then return slot, it end
    end
end

local function isOpen(it)
    local o = it.Open()
    return o == true or o == 1
end

-- Where an ingredient is in your bags, skipping the medicine bag itself.
local function findItemLocation(name, skipSlot)
    for slot = 23, 34 do
        if slot ~= skipSlot then
            local it = mq.TLO.Me.Inventory(slot)
            if it() then
                if (it.Container() or 0) > 0 then
                    for j = 1, it.Container() do
                        local sub = it.Item(j)
                        if sub() and sub.Name() == name then
                            return string.format('in %s %d', packName(slot), j), sub.Stack() or 1
                        end
                    end
                elseif it.Name() == name then
                    return packName(slot), it.Stack() or 1
                end
            end
        end
    end
end

local function clearCursor()
    local n = 0
    while mq.TLO.Cursor.ID() and n < 20 do
        mq.cmd('/autoinventory')
        waitFor(1000, function() return not mq.TLO.Cursor.ID() end)
        n = n + 1
    end
end

local function emptyBag(slot, bag)
    for i = 1, (bag.Container() or 0) do
        if bag.Item(i)() then
            mq.cmdf('/nomodkey /shift /itemnotify in %s %d leftmouseup', packName(slot), i)
            waitFor(1500, function() return mq.TLO.Cursor.ID() ~= nil end)
            clearCursor()
        end
    end
end

local function combineOnce(slot, bag, recipe)
    local pack = packName(slot)
    local i = 0
    for mat, qty in pairs(recipe.mats) do
        for _ = 1, qty do
            i = i + 1
            local loc = findItemLocation(mat, slot)
            if not loc then return false, 'out of ' .. mat end
            mq.cmdf('/nomodkey /ctrl /itemnotify %s leftmouseup', loc)
            if not waitFor(2000, function() return mq.TLO.Cursor.ID() ~= nil end) then return false, 'could not pick up ' .. mat end
            mq.cmdf('/nomodkey /itemnotify in %s %d leftmouseup', pack, i)
            if not waitFor(2000, function() return mq.TLO.Cursor.ID() == nil end) then
                clearCursor()
                return false, 'could not place ' .. mat .. ' in the medicine bag'
            end
        end
    end
    mq.cmdf('/combine %s', pack)
    waitFor(3000, function() return mq.TLO.Cursor.ID() ~= nil or (bag.Items() or 0) == 0 end)
    mq.delay(300)
    clearCursor()
    if (bag.Items() or 0) > 0 then emptyBag(slot, bag) end -- leftovers from a failed combine
    return true
end

------------------------------------------------------------------------
-- New tradeskill window: search the recipe, select it, press Combine.
-- The game pulls the ingredients from your bags itself, so there's no
-- item-by-item placement. Falls back to the old method for any recipe that
-- isn't in your known-recipes list yet.
------------------------------------------------------------------------
local function tsWnd(child) return mq.TLO.Window('TradeskillWnd/' .. child) end

local function hasMats(recipe)
    for mat, qty in pairs(recipe.mats) do
        if A.count(mat) < qty then return false, 'out of ' .. mat end
    end
    return true
end

-- Find the row in the recipe list whose name matches (any column, exact, then prefix)
local function findRecipeRow(list, name)
    local want = name:lower()
    local n = list.Items() or 0
    local prefixRow
    for row = 1, n do
        for col = 1, 3 do
            local ok, t = pcall(function() return list.List(row, col)() end)
            if ok and t and t ~= '' then
                local tl = t:lower()
                if tl == want then return row end
                if not prefixRow and tl:sub(1, #want) == want then prefixRow = row end
            end
        end
    end
    return prefixRow
end

-- Pause between tradeskill-window steps (ms); set from the window's slider.
A.combineDelay = 1000
local function tpause(mult) mq.delay(math.floor(A.combineDelay * (mult or 1))) end

local function curSel(list)
    local ok, v = pcall(function() return list.GetCurSel() end)
    return ok and v or nil
end

-- Search for the recipe and select it. Waits for the result list to update
-- (old results stay on screen briefly) and confirms the selection stuck.
local function tsSelectRecipe(itemName)
    local edit = tsWnd('COMBW_SearchTextEdit')
    if not edit() then return false, 'search box not found' end
    local list = tsWnd('COMBW_RecipeList')

    local ok = pcall(function() edit.SetText('') end)
    if not ok then return false, 'could not type in the search box' end
    tpause(0.3)
    -- The box only holds about 20 characters ("Distillate of Spirituality IX" becomes
    -- "Distillate of Spiritu"). That's fine: it's a partial-name search, and the exact
    -- recipe is picked from the results below.
    pcall(function() edit.SetText(itemName) end)
    tpause(0.5)
    local typed = edit.Text() or ''
    if typed == '' or itemName:lower():sub(1, #typed) ~= typed:lower() then
        return false, 'search box shows "' .. typed .. '"'
    end

    tsWnd('COMBW_SearchButton').LeftMouseUp()
    tpause(1) -- let the old results clear and the new ones load

    local row
    if not waitFor(5000, function() row = findRecipeRow(list, itemName); return row ~= nil end) then
        return false, 'not in your known recipes yet'
    end
    tpause(0.5)
    row = findRecipeRow(list, itemName) -- look again once the list has settled
    if not row then return false, 'recipe disappeared from the list' end

    for _ = 1, 3 do
        pcall(function() list.Select(row) end)
        tpause(0.5)
        local cs = curSel(list)
        if cs == nil or cs == row then return true, row end -- nil: can't read selection, trust the click
    end
    return false, 'could not select the recipe in the list'
end

-- Make sure our recipe is still the selected one (the game can clear it after a combine)
local function tsEnsureSelected(itemName)
    local list = tsWnd('COMBW_RecipeList')
    local row = findRecipeRow(list, itemName)
    if row and curSel(list) == row then return true end
    if row then
        pcall(function() list.Select(row) end)
        tpause(0.5)
        local cs = curSel(list)
        if cs == nil or cs == row then return true end
    end
    return tsSelectRecipe(itemName) -- list was reset; search again
end

local function tsCombineOnce(recipe)
    local ok, err = hasMats(recipe)
    if not ok then return false, err end
    ok, err = tsEnsureSelected(recipe.item)
    if not ok then return false, 'reselecting recipe: ' .. tostring(err) end

    local mat1 = next(recipe.mats)
    local m0, p0 = A.count(mat1), A.count(recipe.item)
    local btn = tsWnd('COMBW_CombineButton')
    if not waitFor(5000, function() return btn.Enabled() end) then
        return false, 'Combine button is greyed out'
    end
    btn.LeftMouseUp()
    -- the combine has happened once ingredients are used up (success or fail)
    if not waitFor(6000, function()
            return A.count(mat1) < m0 or mq.TLO.Cursor.ID() ~= nil or A.count(recipe.item) > p0
        end) then
        return false, 'nothing happened'
    end
    -- a success puts the potion on the cursor; give it a moment, then put it away
    waitFor(1500, function() return mq.TLO.Cursor.ID() ~= nil or A.count(recipe.item) > p0 end)
    clearCursor()
    tpause(1) -- let the window finish updating before the next combine
    return true
end

-- Open the medicine bag in the new tradeskill window (not the old container view)
local function openTradeskill(slot, bag)
    if mq.TLO.Window('TradeskillWnd').Open() then return true end
    if isOpen(bag) then -- old container view is open; close it first
        mq.cmdf('/nomodkey /itemnotify %s rightmouseup', packName(slot))
        waitFor(2000, function() return not isOpen(bag) end)
    end
    mq.cmdf('/nomodkey /itemnotify %s rightmouseup', packName(slot))
    if not waitFor(4000, function() return mq.TLO.Window('TradeskillWnd').Open() end) then return false end
    -- wait for the search box to be there, then give the window time to finish loading
    if not waitFor(4000, function() return tsWnd('COMBW_SearchTextEdit')() ~= nil end) then return false end
    tpause(1.5)
    return true
end

local function closeMedBag(slot, bag)
    if mq.TLO.Window('TradeskillWnd').Open() then mq.TLO.Window('TradeskillWnd').DoClose(); mq.delay(300) end
    if isOpen(bag) then mq.cmdf('/nomodkey /itemnotify %s rightmouseup', packName(slot)); mq.delay(300) end
end

-- One potion, old method: Experiment view, place each ingredient, /combine
local function makeLegacy(slot, bag, e)
    local r = e.recipe
    if mq.TLO.Window('TradeskillWnd').Open() then
        tsWnd('COMBW_ExperimentButton').LeftMouseUp()
        waitFor(2000, function() return isOpen(bag) end)
    elseif not isOpen(bag) then
        mq.cmdf('/nomodkey /itemnotify %s rightmouseup', packName(slot))
        waitFor(2000, function() return isOpen(bag) end)
    end
    local tries, maxTries = 0, e.combines * 2 + 5
    while A.count(r.item) < e.units and tries < maxTries and not A.stopRequested do
        tries = tries + 1
        local ok, err = combineOnce(slot, bag, r)
        if not ok then say('\ar%s: %s.', r.item, err); break end
    end
    closeMedBag(slot, bag)
end

function A.makeAll(plan)
    local slot, bag = findMedBag()
    if not slot then
        say('\arNo medicine bag found in your main bag slots.')
        return false
    end
    if (bag.Items() or 0) > 0 then
        say('\arYour medicine bag is not empty. Empty it and press the button again.')
        return false
    end

    clearCursor()
    A.closeMerchant()

    local allOk = true
    for _, key in ipairs(plan.potionOrder) do
        if A.stopRequested then break end
        local e = plan.potions[key]
        local r = e.recipe
        if A.count(r.item) < e.units then
            local useNew, why = openTradeskill(slot, bag), 'the tradeskill window did not open'
            if useNew then tpause(1); useNew, why = tsSelectRecipe(r.item) end

            if useNew then
                say('%s: using recipe search.', r.item)
                local tries, maxTries = 0, e.combines * 2 + 5
                local stalls = 0
                while A.count(r.item) < e.units and tries < maxTries and not A.stopRequested do
                    tries = tries + 1
                    local ok, err = tsCombineOnce(r)
                    if ok then
                        stalls = 0
                    elseif tostring(err):find('^out of') then
                        say('\ar%s: %s.', r.item, err); break
                    else
                        stalls = stalls + 1
                        say('\ay%s: %s (try %d of 3).', r.item, err, stalls)
                        if stalls >= 3 then break end
                        tpause(2)
                    end
                end
            else
                say('\ay%s: %s, placing ingredients by hand instead.', r.item, tostring(why))
                makeLegacy(slot, bag, e)
            end
        end

        local have = A.count(r.item)
        if have >= e.units then
            say('\agHave %d/%d %s.', have, e.units, r.item)
        else
            say('\ayOnly %d/%d %s.', have, e.units, r.item)
            allOk = false
        end
    end

    closeMedBag(slot, bag)
    A.closeBagsAndInventory() -- any bags opened while combining, inventory
    return allOk
end

------------------------------------------------------------------------
-- Parceling in the Bazaar
------------------------------------------------------------------------
-- Parcel steps wait this long (ms) between actions. Raised from the window's
-- "Parcel step delay" setting if the game needs more time.
A.parcelDelay = 1000

local function pause(mult) mq.delay(math.floor(A.parcelDelay * (mult or 1))) end

local function setText(wnd, text)
    for _ = 1, 3 do
        local w = mq.TLO.Window(wnd)
        if not w() then return false, wnd .. ' not found' end
        local ok, err = pcall(function() w.SetText(text) end)
        if not ok then return false, 'SetText not supported: ' .. tostring(err) end
        pause(0.5)
        if (w.Text() or '') == text then return true end
    end
    return false, string.format('field shows "%s"', tostring(mq.TLO.Window(wnd).Text()))
end

local function ensureParcelTab(npc)
    if not mq.TLO.Window('MerchantWnd').Open() then
        if not A.openMerchant(npc) then return false, 'merchant window would not open' end
        pause()
    end
    mq.cmd('/nomodkey /notify MerchantWnd MW_MerchantSubwindows tabselect 3')
    pause()
    if not mq.TLO.Window('MerchantWnd/MW_Send_Button')() then return false, 'Parcels tab did not open' end
    return true
end

-- Send one stack (or part of one). Returns how many left the bags, and an error if none did.
local function sendItem(npc, player, name, qty)
    local loc, stack = findItemLocation(name, nil)
    if not loc then return 0, 'no ' .. name .. ' left in bags' end
    local sendQty = math.min(stack, qty)
    local before = A.count(name)

    local ok, err = ensureParcelTab(npc)
    if not ok then return 0, err end

    -- the game can clear the recipient after each send, so set it every time
    ok, err = setText('MerchantWnd/MW_Send_To_Edit', player)
    if not ok then return 0, 'recipient: ' .. err end
    pause(0.5)

    -- Clicking a bag item while the merchant is open selects it. The item's name
    -- shows in MW_SelectedItemLabel ("Item Being Considered" when nothing is selected).
    -- MacroQuest's Merchant.SelectedItem is checked too, in case the label differs.
    local function labelText() return mq.TLO.Window('MerchantWnd/MW_SelectedItemLabel').Text() or '' end
    local function mqSelected() return mq.TLO.Merchant.SelectedItem.Name() or '' end
    local function isSelected()
        local want = name:lower()
        return labelText():lower():find(want, 1, true) ~= nil or mqSelected():lower() == want
    end
    mq.cmdf('/nomodkey /itemnotify %s leftmouseup', loc)
    if not waitFor(3000, isSelected) then
        return 0, string.format('select item (v3): label "%s", MQ selected "%s", clicked %s, merchant window %s',
            labelText(), mqSelected(), loc, mq.TLO.Window('MerchantWnd').Open() and 'open' or 'CLOSED')
    end
    pause()

    if not waitFor(3000, function() return mq.TLO.Window('MerchantWnd/MW_Send_Button').Enabled() end) then
        return 0, 'Send button stayed greyed out'
    end
    mq.cmd('/nomodkey /notify MerchantWnd MW_Send_Button leftmouseup')
    pause(0.5)

    -- A quantity box may pop up; answer it, then wait for the stack to leave the bags.
    local answered = false
    waitFor(10000, function()
        if not answered and mq.TLO.Window('QuantityWnd').Open() then
            setText('QuantityWnd/QTYW_SliderInput', tostring(sendQty))
            mq.cmd('/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
            answered = true
        end
        return A.count(name) < before
    end)
    pause()
    local sent = before - A.count(name)
    if sent <= 0 then return 0, 'clicked Send but nothing left the bags' end
    return sent
end

--- Parcel each order and mark it complete. orders: list; data: gp_recipes
function A.parcelAll(orders, data)
    -- Don't make the trip if no order is ready to send
    local anyReady = false
    for _, order in ipairs(orders) do
        local units, missing = Plan.orderUnits(order, data)
        local ready = #missing == 0
        for item, n in pairs(units) do
            if A.count(item) < n then ready = false end
        end
        if ready then anyReady = true; break end
    end
    if not anyReady then
        say('\ayNo order has all its potions yet, so nothing to parcel.')
        return false
    end

    if not A.travelTo('bazaar') then return false end
    local npc = A.findParcelNpc()
    if not npc then
        say('\arNo "Parcels" merchant found in the Bazaar.')
        return false
    end
    if not (A.navTo(npc) and A.openMerchant(npc)) then return false end
    pause(2) -- give the merchant window time to finish loading
    local tabOk, tabErr = ensureParcelTab(npc)
    if not tabOk then
        say('\arParcel: %s.', tabErr)
        A.closeMerchant()
        return false
    end

    local done = 0
    for _, order in ipairs(orders) do
        if A.stopRequested then break end
        local units, missing = Plan.orderUnits(order, data)
        local short = {}
        for item, n in pairs(units) do
            if A.count(item) < n then short[#short + 1] = string.format('%d %s', n - A.count(item), item) end
        end

        if #missing > 0 then
            say('\ay%s: has %s, which the script has no recipe for. Parcel this order yourself.', order.playerName, table.concat(missing, ', '))
        elseif #short > 0 then
            say('\ay%s: not enough potions yet (short %s). Skipped.', order.playerName, table.concat(short, ', '))
        else
            say('Parceling to %s...', order.playerName)
            local ok = true
            for item, n in pairs(units) do
                -- "left" always comes from the real bag count, so a send that
                -- goes through late is never sent a second time on retry
                local startCount = A.count(item)
                local left, tries, lastErr = n, 0, nil
                while left > 0 and tries < 3 and not A.stopRequested do
                    local sent, err = sendItem(npc, order.playerName, item, left)
                    left = n - (startCount - A.count(item))
                    if sent > 0 then
                        tries = 0
                        say('  sent %d %s (%d to go)', sent, item, left)
                    else
                        tries = tries + 1
                        lastErr = err
                        say('\ay  try %d failed at step "%s"', tries, tostring(err))
                        pause(2)
                    end
                end
                if left > 0 then
                    say('\arParcel to %s stopped with %d %s not sent (%s).', order.playerName, left, item, tostring(lastErr))
                    ok = false
                    break
                end
            end
            if ok then
                local marked, err = FS.markComplete(order.id)
                if marked then
                    say('\agParceled %s\'s order and marked it complete.', order.playerName)
                    order.completed = true
                    done = done + 1
                else
                    say('\ayParceled %s\'s order, but marking it complete failed: %s', order.playerName, err)
                end
            end
        end
    end
    A.closeMerchant()
    A.closeBagsAndInventory()
    say('Parceling finished: %d of %d orders sent.', done, #orders)
    return done == #orders
end

return A
