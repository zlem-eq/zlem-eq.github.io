-- Guild Potions - minimal JSON encode/decode (enough for the Firestore REST API)

local json = {}

local escapes = { ['"'] = '\\"', ['\\'] = '\\\\', ['\b'] = '\\b', ['\f'] = '\\f', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t' }

local function isArray(t)
    if next(t) == nil then return false end
    local n = 0
    for k in pairs(t) do
        if type(k) ~= 'number' then return false end
        n = n + 1
    end
    return n == #t
end

function json.encode(v)
    local t = type(v)
    if t == 'nil' then return 'null' end
    if t == 'boolean' then return tostring(v) end
    if t == 'number' then return string.format('%.14g', v) end
    if t == 'string' then
        return '"' .. v:gsub('[%c"\\]', function(c)
            return escapes[c] or string.format('\\u%04x', c:byte())
        end) .. '"'
    end
    if t == 'table' then
        local out = {}
        if isArray(v) then
            for _, x in ipairs(v) do out[#out + 1] = json.encode(x) end
            return '[' .. table.concat(out, ',') .. ']'
        end
        for k, x in pairs(v) do out[#out + 1] = json.encode(tostring(k)) .. ':' .. json.encode(x) end
        return '{' .. table.concat(out, ',') .. '}'
    end
    error('cannot encode ' .. t)
end

local function utf8char(cp)
    if cp < 0x80 then return string.char(cp) end
    if cp < 0x800 then return string.char(0xC0 + math.floor(cp / 0x40), 0x80 + cp % 0x40) end
    if cp < 0x10000 then
        return string.char(0xE0 + math.floor(cp / 0x1000), 0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40)
    end
    return string.char(0xF0 + math.floor(cp / 0x40000), 0x80 + math.floor(cp / 0x1000) % 0x40,
        0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40)
end

function json.decode(s)
    local pos = 1

    local function err(msg) error(string.format('JSON %s at position %d', msg, pos), 0) end
    local function ws() pos = s:find('[^ \t\r\n]', pos) or (#s + 1) end

    local value

    local function str()
        pos = pos + 1 -- opening quote
        local buf = {}
        while true do
            local c = s:sub(pos, pos)
            if c == '' then err('unterminated string') end
            if c == '"' then pos = pos + 1; break end
            if c == '\\' then
                local e = s:sub(pos + 1, pos + 1)
                local map = { b = '\b', f = '\f', n = '\n', r = '\r', t = '\t', ['"'] = '"', ['\\'] = '\\', ['/'] = '/' }
                if map[e] then
                    buf[#buf + 1] = map[e]; pos = pos + 2
                elseif e == 'u' then
                    local cp = tonumber(s:sub(pos + 2, pos + 5), 16) or err('bad \\u escape')
                    pos = pos + 6
                    if cp >= 0xD800 and cp <= 0xDBFF and s:sub(pos, pos + 1) == '\\u' then
                        local lo = tonumber(s:sub(pos + 2, pos + 5), 16)
                        if lo and lo >= 0xDC00 and lo <= 0xDFFF then
                            cp = 0x10000 + (cp - 0xD800) * 0x400 + (lo - 0xDC00)
                            pos = pos + 6
                        end
                    end
                    buf[#buf + 1] = utf8char(cp)
                else
                    err('bad escape')
                end
            else
                local stop = s:find('["\\]', pos) or (#s + 1)
                buf[#buf + 1] = s:sub(pos, stop - 1)
                pos = stop
            end
        end
        return table.concat(buf)
    end

    function value()
        ws()
        local c = s:sub(pos, pos)
        if c == '{' then
            pos = pos + 1
            local obj = {}
            ws()
            if s:sub(pos, pos) == '}' then pos = pos + 1; return obj end
            while true do
                ws()
                if s:sub(pos, pos) ~= '"' then err('expected key') end
                local k = str()
                ws()
                if s:sub(pos, pos) ~= ':' then err('expected :') end
                pos = pos + 1
                obj[k] = value()
                ws()
                local d = s:sub(pos, pos)
                pos = pos + 1
                if d == '}' then return obj end
                if d ~= ',' then err('expected , or }') end
            end
        elseif c == '[' then
            pos = pos + 1
            local arr = {}
            ws()
            if s:sub(pos, pos) == ']' then pos = pos + 1; return arr end
            while true do
                arr[#arr + 1] = value()
                ws()
                local d = s:sub(pos, pos)
                pos = pos + 1
                if d == ']' then return arr end
                if d ~= ',' then err('expected , or ]') end
            end
        elseif c == '"' then
            return str()
        elseif s:sub(pos, pos + 3) == 'true' then
            pos = pos + 4; return true
        elseif s:sub(pos, pos + 4) == 'false' then
            pos = pos + 5; return false
        elseif s:sub(pos, pos + 3) == 'null' then
            pos = pos + 4; return nil
        else
            local num = s:match('^-?%d+%.?%d*[eE]?[-+]?%d*', pos)
            if not num or num == '' then err('unexpected character') end
            pos = pos + #num
            return tonumber(num)
        end
    end

    local ok, result = pcall(function()
        local v = value()
        ws()
        if pos <= #s then err('trailing text') end
        return v
    end)
    if ok then return result end
    return nil, result
end

return json
